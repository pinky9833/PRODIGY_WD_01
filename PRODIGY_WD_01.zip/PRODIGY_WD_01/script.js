document.addEventListener("DOMContentLoaded", function() {
    const navbar = document.querySelector('.navbar');
    const navMenu = document.querySelector('.nav-menu');
    const navToggle = document.createElement('div');
    
    navToggle.classList.add('nav-toggle');
    navToggle.innerHTML = '&#9776;';
    navbar.insertBefore(navToggle, navMenu);

    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    navToggle.addEventListener('click', function() {
        navMenu.classList.toggle('active');
    });
});
